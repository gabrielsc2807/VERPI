export class Usuario {
    id: number
    nome: string
    senha: string
    tipo: number

    constructor(){
        this.id = 0
        this.nome = ''
        this.senha = ''
        this.tipo = 0
    }
}
