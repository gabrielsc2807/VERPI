import { Aluno } from './aluno';

describe('Aluno', () => {
  it('should create an instance', () => {
    expect(new Aluno()).toBeTruthy();
  });
});
