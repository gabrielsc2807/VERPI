export class Nota {
    id: number;
    nota: number;

    constructor(){
        this.id=0;
        this.nota=0;
    }
}
