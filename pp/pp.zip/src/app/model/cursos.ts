export class Cursos {
    id:number;
    descricao:String;
    cotas:String[];

    constructor(){
        this.id=0;
        this.descricao="";
        this.cotas= [];
    }
}
