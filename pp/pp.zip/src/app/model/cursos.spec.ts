import { Cursos } from './cursos';

describe('Cursos', () => {
  it('should create an instance', () => {
    expect(new Cursos()).toBeTruthy();
  });
});
