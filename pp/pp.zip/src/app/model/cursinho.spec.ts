import { Cursinho } from './cursinho';

describe('Cursinho', () => {
  it('should create an instance', () => {
    expect(new Cursinho()).toBeTruthy();
  });
});
